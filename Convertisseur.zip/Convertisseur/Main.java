/* Nikolaï BIROLINI
   EISE3-G1

   DM GRAPHIQUE JAVA : Convertisseur Euros/Dollars
*/

import javax.swing.JFrame;

public class Main{

	public static void main(String[] args){

		converter onglet = new converter(); //Lance la fenêtre

		//Question 2 

		/*onglet.setTaux(1.09);
		double resDol = onglet.toDollars(100);
		double resEuro = onglet.toEuros(200);

		System.out.println("100 euros = "+ resDol +"$ et " + "200$ = "+ resEuro + " euros");*/

	}
}