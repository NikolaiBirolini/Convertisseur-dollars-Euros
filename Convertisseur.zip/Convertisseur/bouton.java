/* Nikolaï BIROLINI
   EISE3-G1

   DM GRAPHIQUE JAVA : Convertisseur Euros/Dollars
*/

import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

//Classe pur les boutons héritage de JButton et relié à l'interface MouseListener
public class bouton extends JButton implements MouseListener{

	private String name; //Nom du bouton

	public bouton(String str) //Constructeur
	{
		super(str);
		this.name = str; //On lui ajoute son nom
		this.addMouseListener(this); //Le bouton surveille la souris
	}

  //Fonction lui donnant sa forme et sa couleur dégradée orange et rouge
	public void paintComponent(Graphics g){

		Graphics2D g2d = (Graphics2D)g;
    	GradientPaint gp = new GradientPaint(0, 0, Color.red, 0, 20, Color.orange, true);
    	g2d.setPaint(gp);
    	g2d.fillRect(0, 0, this.getWidth(), this.getHeight());
    	g2d.setColor(Color.black);
    	g2d.drawString(this.name, (this.getWidth()-50) / 2, (this.getHeight() / 2) + 5); 
	}

	 //Méthode appelée lors du clic de souris
  	public void mouseClicked(MouseEvent event) { 


  	}

  	//Méthode appelée lors du survol de la souris
  	public void mouseEntered(MouseEvent event) { 

  	}

 	//Méthode appelée lorsque la souris sort de la zone du bouton
  	public void mouseExited(MouseEvent event) { 

  	}

  	//Méthode appelée lorsque l'on presse le bouton gauche de la souris
  	public void mousePressed(MouseEvent event) { 

  	}

  	//Méthode appelée lorsque l'on relâche le clic de souris
  	public void mouseReleased(MouseEvent event) { 

  	} 
}