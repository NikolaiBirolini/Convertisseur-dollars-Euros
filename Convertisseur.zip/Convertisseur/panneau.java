import javax.swing.JPanel;
/* Nikolaï BIROLINI
   EISE3-G1

   DM GRAPHIQUE JAVA : Convertisseur Euros/Dollars
*/
import java.awt.Graphics;
import java.awt.Font;
import java.awt.Color;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.GradientPaint;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

//Classe du panneau qui hérite de JPanel
public class panneau extends JPanel {

	public void paintComponent(Graphics g){
		//Test d'invocation de méthode
		System.out.println("Je suis exécuté !");
		//Pour que le cercle reste toujours au milieu
		int x1=this.getWidth()/4;
		int y1=this.getHeight()/4;
		//g.fillOval(x1, y1,this.getWidth()/2,this.getHeight()/2); // cercle plein
		//g.drawOval(20,20,75,75);//Cercle
		//g.drawRect(10,10,10,10);//Rectangle
		//g.drawRoundRect(10,10,10,10);
		//g.drawLine(xD,yD,xA,yA);
		//g.drawString("blablablabal",10,20);

		//Ecriture changement de police et de couleur

		/*Font font = new Font("Courier", Font.BOLD,20);
		g.setFont(font);
		g.setColor(Color.blue);
		g.drawString("blablablabal",10,20);*/

		//Insérer une image
		/*try{
			Image img = ImageIO.read(new File("Images.png"));
			g.drawImage(img,0,0,this);

		} catch (IOException e){
			e.printStackTrace();
		}*/

		//Dégradé
		
		/*Graphics2D g2d = (Graphics2D)g;
		GradientPaint gp = new GradientPaint(0,0,Color.RED,30,30,Color.cyan,true);
		g2d.setPaint(gp);
		g2d.fillRect(0,0,this.getWidth(),this.getHeight());*/
	}
}