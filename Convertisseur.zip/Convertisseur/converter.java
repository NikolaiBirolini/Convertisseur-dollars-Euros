/* Nikolaï BIROLINI
   EISE3-G1

   DM GRAPHIQUE JAVA : Convertisseur Euros/Dollars
*/
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;

public class converter extends JFrame {

	private panneau pan = new panneau(); //Définition du panneau
	
	private bouton boutonQ = new bouton("Quitter"); //Définition du bouton quitter
	
	private JPanel container = new JPanel(); //Définition du conteneur c'est une couche de la fenêtre accueillant les composants
	
	//Définition des labels, texte afficher sur la fenêtre
	private JLabel label = new JLabel("TAUX: 1  = ");
	private JLabel euroFleche = new JLabel ("==>");
	private JLabel dollFleche = new  JLabel("<==");
	private JLabel dol = new JLabel("$");
	private JLabel dol2 = new JLabel("$");
	private JLabel euro = new JLabel("€");
	private JLabel euro2 = new JLabel("€");

	//Définition du composant JSpinner
	private SpinnerNumberModel modeTaux = new SpinnerNumberModel(0,0,100,0.01);//Selection du mode, il commence à 1, minimu 0, maximum 100 et a un pas de 0.01
	private JSpinner jtfTaux = new JSpinner(modeTaux);//Association du mode avec le composant afin de le définir

	//Définition des JtextFields
	private JTextField jtfEuros = new JTextField("Euros");//Définition de la case euro
	private JTextField jtfDollars = new JTextField("Dollars");//Définition de la case dollar

	//Définition des boîtes de dialogue pour les exceptions pour les deux JTextFields et le JSpinner
	private JOptionPane jopEuros = new JOptionPane();
	private JOptionPane jopDoll = new JOptionPane();
	private JOptionPane jopTaux = new JOptionPane();
	
	private double taux; //Définition de la variable taux qui contiendra le taux de change.

	//Constructeur de la fenêtre
	public converter(){

		//Fonction gérant le bouton "Quitter"
		boutonQ.addMouseListener(new MouseAdapter(){

			public void mouseClicked(MouseEvent e){ //Si jamais la souris clique sur le bouton "Quitter"
				
				int x = e.getX();
				int y = e.getY();
				
				//System.out.println(x +"," + y); //Sert à afficher la position x et y où la souris clique
				
				if ((x > 5)&&(200 > x)&&(y > 5 )&&(42 > y)) //On délimite la zone de réaction du clique sur le bouton Quitter 
				{
					System.exit(0); //Ainsi, si on clique dans cette zone, on quitte la fenêtre et on arrête le programme
				}
			}
		});

		//Fonction gérant le JTextFields Euros
		jtfEuros.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e){ //Si jamais on appuie sur entrée
				
				try{
						
						container.add(euroFleche); //On ajoute la fleche indiquant le sens de conversion "==>"
						euroFleche.setBounds(130,0,100,70); //On indique sa position
						double dollars = toDollars(Double.parseDouble(jtfEuros.getText())); //On récupere ce qu'il y a d'écrit dans la case Euros et on effectue une conversion de type en double
						
						//System.out.println("Dollars = " + dollars); //Permet de vérifier sur la console la valeur en dollars
						
						dollars = arrondir (dollars, 3); //Fonction permettant d'arrondir à 3 chiffres après la virgule la valeur calculée

						jtfDollars.setText(String.valueOf(dollars)); //Affiche le résultat de la conversion dans la case dollars
						dollFleche.setBounds(500,500,100,70); //On enleve la fleche de conversion dollars euros "<==" en la mettant hors cadre
						
						
					//Si jamais la l'utilisateur écrit un String dans la case euros alors une exception se déclenche
					}catch(Exception ex){
										jopEuros.showMessageDialog(null,"Pas de String dans la case Euros","Erreur",JOptionPane.ERROR_MESSAGE); //Affiche le message d'erreur dans une boîte de dialogue
										
										//System.out.println(ex.getMessage()); //Permet d'afficher le message dans le terminal
										}				
			}
		});

		//Fonction gérant le JTextField Dollars
		jtfDollars.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e){ //Si jamais on appuie sur entrée

				try{

					container.add(dollFleche); //On ajoute la fleche indiquant le sens de conversion "<=="
					dollFleche.setBounds(130,0,100,70);//On indique sa position
					double euros = toEuros(Double.parseDouble(jtfDollars.getText())); //On recupere ce qu'il y a d'écrit dans la case dollar et on effectue une conversion de type en double.
					euros = arrondir (euros, 3);//Fonction permettant d'arrondir à 3 chiffres après la virgule la valeur calculée

					//System.out.println("Euros = " + euros); //Permet d'afficher sur le terminal la valeur en euros
					
					jtfEuros.setText(String.valueOf(euros)); //Affiche dans la case euros, la valeur de la conversion 

					euroFleche.setBounds(500,500,100,70); // On retire la fleche de conversion euros à dollars "==>", en la mettant hors champ

				//Si jamais l'utilisateur écrit un String dans la case dollars alors une exception se déclenche
				}catch(Exception ex){

					jopDoll.showMessageDialog(null,"Pas de String dans la case Dollars","Erreur",JOptionPane.ERROR_MESSAGE); //Affiche une boîte de dialogue indiquant à l'utilisateur l'erreur

					//System.out.println(ex.getMessage()); //Permet d'afficher l'exception sur le terminal
				}
			}
		});

		//Fonction permettant de gérer le JSpinner
		jtfTaux.addChangeListener(new ChangeListener(){

			public void stateChanged(ChangeEvent e){ //Si la valeur du JSpinner change alors

				try {

					jtfTaux.commitEdit(); //Valide la valeur rentrée dans le JSpinner

				//Si jamais l'utilisateur rentre une valeur invalide 
				}catch(Exception ex){

										jopTaux.showMessageDialog(null,"Valeur invalide","Erreur",JOptionPane.ERROR_MESSAGE); //Affiche le message d'erreur dans une boîte de dialogue
										
										//System.out.println(ex.getMessage()); //Affiche le message dans le terminal
									}

				double value = (double) jtfTaux.getValue(); //Prends la valeur et la convertit en double
				setTaux(value);//Ajoute la valeur du Taux dans la variable "taux"
				
			}
		});

		
		this.setTitle("Convertisseur");//Titre de la fenetre
		this.setSize(300,220);//Taille de la fenetre avec les pixels
		this.setLocationRelativeTo(null); //Positionner au centre
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //Fermeture croix rouge	
		this.setResizable(false);//Pouvoir redimensionner la fenetre
		this.setAlwaysOnTop(true);//Toujours au premier plan

		container.setLayout(null); //Centrer le container
		container.setBackground(Color.white); //Mettre un fond blanc
	
		container.add(pan);
		container.add(boutonQ); //Ajout du bouton "Quitter"
		boutonQ.setBounds(50,120,200,50); //On indique sa position

		jtfTaux.setBounds(120,70,150,30); //On indique la position du JSpinner pour le Taux
		container.add(jtfTaux); //On ajoute le JSpinner
		label.setBounds(40,70,150,30); //On indique la position du label "Taux 1 euro ="
		container.add(label); //On ajoute le texte "Taux 1 euro ="


		jtfEuros.setBounds(20,20,100,30); //On indique la position du JTextField pour la case euro  
		container.add(jtfEuros);//On ajoute le JTextField pour la case euro

		//Ajout des diférents symboles (euros et dollars)
		dol.setBounds(270,0,100,70);
		container.add(dol);

		dol2.setBounds(270,50,100,70);
		container.add(dol2);

		euro.setBounds(120,0,100,70);
		container.add(euro);

		euro2.setBounds(92,50,100,70);
		container.add(euro2);


		jtfDollars.setBounds(170,20,100,30); //On indique la position du JTextField dollar
		container.add(jtfDollars);//On ajoute le JTextField

		//boutonQ.addActionListener(this);
		this.setContentPane(container);//On indique que le panneau de la fenetre est le container
		
		this.setVisible(true);//Rend la fenêtre visible

	}

	//Fonction qui prend en entrée les euros et les convertit en dollars
	public double toDollars(double s){
		double d=0;
		d=s*taux;
		return d;

	}

	//Fonction qui prend en entrée les dollars et les convertit en euros
	public double toEuros(double s){
		double e=0;

		e=s/taux;
		return e;
	}
	//Fonction définissant le Taux
	public void setTaux(double t){
		taux=t;
	}

	//Fonction prenant en entrée la valeur à arrondir et le nombre de chiffre après la virgule voulu
	public double arrondir (double nombre, double nbApVirg)
	{
		return (double)((int)(nombre*Math.pow(10,nbApVirg)+.5))/Math.pow(10,nbApVirg);
	}
}
